print('-=-'*15)
print('BANÁRIO PARA DECIMAL')
print('-=-'*15)


numero_binario = input('Digite um número em BINÁRIO: ')
numero_decimal = int(numero_binario, 2)
print(numero_decimal)