print('-=-'*8)
print('RESTO 5')
print('-=-'*8)

for c in range(1000, 2000):
    if (c / 11) % 5:
        print(c)