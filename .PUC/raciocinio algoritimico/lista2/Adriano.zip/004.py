print('-=-'*8)
print('ORDEM MAIOR MENOR')
print('-=-'*8)

lista = []
c = 0 
for c in range (5):
    digito = int(input('Digite um valor: '))
    lista.append(int(digito))
    list.sort(lista)
print(lista)