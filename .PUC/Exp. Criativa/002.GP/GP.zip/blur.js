const blur = document.querySelector('.blur');

setInterval(() => {
  blur.classList.toggle('hover')
}, 1000);